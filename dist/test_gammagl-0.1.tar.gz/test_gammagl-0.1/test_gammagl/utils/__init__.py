from .degree import degree


__all__ = [
    'degree'
]

classes = __all__