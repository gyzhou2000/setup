def degree(name):
    print(name)